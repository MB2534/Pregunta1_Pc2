// Obtener elementos del DOM
var contenedor = document.querySelector("#contenedor");
var ampliarLienzo = document.querySelector("#lienzo");
var btnAmpliar = document.querySelector("#btnAmpliar");

// Inicializar canvas y contexto    
var canvas = document.querySelector("#lienzo");
var ctx = canvas.getContext("2d");

// Función para dibujar el cielo (y luego puedes seguir con más)
function dibujarPaisaje() {
    // CIELO con degradado
    var grd = ctx.createLinearGradient(0, 0, 0, 500);
    grd.addColorStop(0, "rgba(65, 217, 255, 0.84)");
    grd.addColorStop(1, "white");
    ctx.fillStyle = grd;
    ctx.fillRect(0, 0, 1000, 600);  // Tamaño del área a pintar

 

   // OCEANO
var grd2 = ctx.createLinearGradient(0, 400, 0, 500);
grd2.addColorStop(0, "rgba(59, 190, 184, 0.5)");
grd2.addColorStop(1, "white");
ctx.fillStyle = grd2;
ctx.fillRect(0, 400, 1000, 100);

// MONTAÑA 1
ctx.beginPath();
ctx.fillStyle = 'rgba(141, 95, 43, 0.89)';
ctx.moveTo(0, 400);
ctx.lineTo(200, 100);
ctx.lineTo(400, 400);
ctx.fill();
// MONTAÑA 2
ctx.beginPath();
ctx.fillStyle = 'rgba(201, 131, 51, 0.89)';
ctx.moveTo(200, 400);
ctx.lineTo(400, 100);
ctx.lineTo(600, 400);
ctx.fill();

// MONTAÑA 3
ctx.beginPath();
ctx.fillStyle = 'rgba(141, 95, 43, 0.89)';
ctx.moveTo(400, 400);
ctx.lineTo(600, 100);
ctx.lineTo(800, 400);
ctx.fill();

// MONTAÑA 4
ctx.beginPath();
ctx.fillStyle = 'rgba(201, 131, 51, 0.89)';
ctx.moveTo(600, 400);
ctx.lineTo(800, 100);
ctx.lineTo(1000, 400);
ctx.fill();

// NIEVE MONTAÑA 1
ctx.beginPath();
ctx.fillStyle = 'rgba(255,255,255,1)';
ctx.moveTo(200, 300);
ctx.lineTo(200, 100);
ctx.lineTo(267, 200);
ctx.fill();

// NIEVE MONTAÑA 2
ctx.beginPath();
ctx.fillStyle = 'rgba(255,255,255,1)';
ctx.moveTo(333, 200);
ctx.lineTo(400, 100);
ctx.lineTo(400, 300);
ctx.fill();


ctx.beginPath();
ctx.fillStyle = 'rgba(150, 107, 44, 0.86)';
ctx.moveTo(200, 300);    // base montaña izquierda
ctx.lineTo(400, 400);    // izquierda
ctx.lineTo(200, 450	);    // derecha
ctx.fill();

ctx.beginPath();
ctx.fillStyle = 'rgba(175, 112, 16, 0.86)';
ctx.moveTo(200, 300);    // Vértice superior (cima)
ctx.lineTo(0, 400);      // Lado izquierdo base
ctx.lineTo(200, 450);    // Vértice inferior derecho
ctx.fill();

ctx.beginPath();
ctx.fillStyle = 'rgba(150, 107, 44, 0.86)';
ctx.moveTo(800, 300);     // vértice superior
ctx.lineTo(600, 400);     // base izquierda
ctx.lineTo(800, 450);     // base inferior
ctx.fill();

ctx.beginPath();
ctx.fillStyle = 'rgba(175, 112, 16, 0.86)';
ctx.moveTo(800, 300);     // vértice superior
ctx.lineTo(1000, 400);    // base derecha
ctx.lineTo(800, 450);     // base inferior
ctx.fill();





//ABAJO
ctx.beginPath();
ctx.fillStyle = 'rgba(255,255,255,1)';
ctx.moveTo(200, 300);
ctx.lineTo(200, 100);
ctx.lineTo(267, 200);
ctx.fill();

// NIEVE MONTAÑA 1 - REFLEJO
ctx.beginPath();
ctx.fillStyle = 'rgba(255,255,255,1)';
ctx.moveTo(133, 200);
ctx.lineTo(200, 100);
ctx.lineTo(200, 300);
ctx.fill();


// NIEVE MONTAÑA 2 - REFLEJO
ctx.beginPath();
ctx.fillStyle = 'rgba(255,255,255,1)';
ctx.moveTo(400, 300);
ctx.lineTo(400, 100);
ctx.lineTo(467, 200);
ctx.fill();

ctx.beginPath();
ctx.fillStyle = 'rgba(255,255,255,1)';
ctx.moveTo(600, 300);
ctx.lineTo(600, 100);
ctx.lineTo(667, 200);
ctx.fill();

// REFLEJO
ctx.beginPath();
ctx.fillStyle = 'rgba(255,255,255,1)';
ctx.moveTo(533, 200);
ctx.lineTo(600, 100);
ctx.lineTo(600, 300);
ctx.fill();

ctx.beginPath();
ctx.fillStyle = 'rgba(255,255,255,1)';
ctx.moveTo(800, 300);     // base vertical
ctx.lineTo(800, 100);     // cima
ctx.lineTo(867, 200);     // lado derecho
ctx.fill();

ctx.beginPath();
ctx.fillStyle = 'rgba(255,255,255,1)';
ctx.moveTo(733, 200);     // lado izquierdo
ctx.lineTo(800, 100);     // cima
ctx.lineTo(800, 300);     // base vertical
ctx.fill();

// Colina izquierda
ctx.beginPath();
ctx.fillStyle = 'rgb(85, 216, 45)';
ctx.arc(0, 500, 250, 0, Math.PI * 2);
ctx.fill();

// Colina derecha
ctx.beginPath();
ctx.fillStyle = 'rgb(147, 221, 125)';
ctx.arc(1000, 500, 250, 0, Math.PI * 2);
ctx.fill();

// Tronco
ctx.fillStyle = "#8B0000";
ctx.fillRect(100, 300, 10, 50);

// Copas
ctx.fillStyle = 'rgb(36, 126, 8)';
ctx.beginPath(); ctx.arc(105, 290, 20, 0, Math.PI * 2); ctx.fill();

ctx.fillStyle = "#004d00";
ctx.beginPath(); ctx.arc(90, 280, 20, 0, Math.PI * 2); ctx.fill();

ctx.fillStyle = "#003300";
ctx.beginPath(); ctx.arc(120, 280, 20, 0, Math.PI * 2); ctx.fill();

// Tronco
ctx.fillStyle = "#8B0000";
ctx.fillRect(900, 300, 10, 50);

// Copas
ctx.fillStyle = 'rgba(58, 155, 16, 0.63)';
ctx.beginPath(); ctx.moveTo(905, 250); ctx.lineTo(875, 300); ctx.lineTo(935, 300); ctx.fill();

ctx.fillStyle = "#004d00";
ctx.beginPath(); ctx.moveTo(905, 230); ctx.lineTo(880, 270); ctx.lineTo(930, 270); ctx.fill();

ctx.fillStyle = "#003300";
ctx.beginPath(); ctx.moveTo(905, 210); ctx.lineTo(885, 240); ctx.lineTo(925, 240); ctx.fill();

for (let i = 0; i < 7; i++) {
  ctx.beginPath();
  ctx.fillStyle = "#006600";
  ctx.arc(30 + i * 30, 500, 15, 0, Math.PI * 2);
  ctx.fill();
}

}



// Función para ampliar el canvas
function ampliar() {
    contenedor.style.width = "100%";
    contenedor.style.height = "100vh";
    contenedor.style.margin = "0";

    ampliarLienzo.style.width = "100%";
    ampliarLienzo.style.height = "100vh";
    ampliarLienzo.style.backgroundSize = "cover";
    ampliarLienzo.style.backgroundRepeat = "no-repeat";

    // Redimensiona internamente el canvas también
    ampliarLienzo.width = window.innerWidth;
    ampliarLienzo.height = window.innerHeight;

    btnAmpliar.innerHTML = "Reducir Canvas";
    btnAmpliar.style.position = "fixed";
    btnAmpliar.style.top = "10px";
    btnAmpliar.style.left = "10px";
    btnAmpliar.style.zIndex = "1";

    btnAmpliar.setAttribute("onClick", "reducir()");

    dibujarPaisaje();
}

// Función para reducir el canvas a su tamaño original
function reducir() {
    contenedor.style.width = "1000px";
    contenedor.style.height = "500px";
    contenedor.style.margin = "5vh auto";

    ampliarLienzo.style.width = "1000px";
    ampliarLienzo.style.height = "500px";

    ampliarLienzo.width = 1000;
    ampliarLienzo.height = 500;

    btnAmpliar.innerHTML = "Ampliar Canvas";
    btnAmpliar.style.position = "relative";
    btnAmpliar.style.top = "0";
    btnAmpliar.style.left = "0";
    btnAmpliar.style.zIndex = "0";

    btnAmpliar.setAttribute("onClick", "ampliar()");

    dibujarPaisaje();
}

// Dibujar al cargar la página
dibujarPaisaje();
